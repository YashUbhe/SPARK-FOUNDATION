# Payment_Gateway

GRIP The Sparks Foundation July 2021 Batch Website with Payment Integration on Donate button.

Using HTML + CSS +  Javascript create website and implement payment integration using Razorpay.
